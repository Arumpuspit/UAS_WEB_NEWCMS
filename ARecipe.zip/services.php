<?php 
include 'partials/header.php'
?>

<section class="empty__page">
    <h1>Services Page</h1>
    <h4>If you experience any confusion, you can contact our services through the social media listed. Contact us today to learn more about how our services can help you.</h4>
</section>

<?php
include './partials/footer.php';
?>