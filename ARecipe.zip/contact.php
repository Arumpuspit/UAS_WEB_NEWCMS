<?php 
include 'partials/header.php'
?>
<section class="empty__page">
    <h1>Contact Page</h1>
    <h4>You can contact one of the social media channels below if you experience any confusion.</h4>
</section>

<?php
include './partials/footer.php';
?>