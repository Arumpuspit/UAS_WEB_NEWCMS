<?php
session_start();
define("ROOT_URL", "http://localhost/newcms/");
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'Arum123*');
define('DB_NAME', 'blogcms');

